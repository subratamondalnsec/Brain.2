const express = require("express");
const { v4: uuidv4 } = require("uuid");
const upload = require("../middleware/upload");
const { getVoiceEmbedding } = require("../services/embeddingService");
const {
  searchVoicePoints,
  upsertVoicePoint,
  countVoicePointsForUser,
} = require("../services/qdrantService");

const router = express.Router();

const MATCH_THRESHOLD = parseFloat(process.env.VOICE_MATCH_THRESHOLD) || 0.88;

/**
 * POST /voice-match
 *
 * Form-data fields:
 *   voice    {file}    required  — audio file
 *   user_id  {string}  optional
 *   date     {string}  optional  — e.g. "2024-06-01"
 *
 * Behaviour:
 *   Case A — user_id provided:
 *     1. Get voice embedding.
 *     2. Search Qdrant filtered to that user_id.
 *     3. If best score >= threshold → match = true.
 *     4. Store the new voice sample for that user_id.
 *
 *   Case B — no user_id:
 *     1. Get voice embedding.
 *     2. Search ALL voice embeddings (identity recognition).
 *     3. If best score >= threshold → match = true, user_id = matched user.
 *     4. If matched, store the new voice sample under that user_id.
 *        If no match → store nothing (no user to attach to).
 */
router.post("/", upload.single("voice"), async (req, res) => {
  try {
    // ── Validate file ────────────────────────────────────────
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: "A voice file is required. Send it as form-data field 'voice'.",
      });
    }

    const { user_id, date } = req.body;
    const incomingUserId = user_id ? user_id.trim() : null;
    const storedDate = date || new Date().toISOString().split("T")[0];

    // ── Get voice embedding ──────────────────────────────────
    const vector = await getVoiceEmbedding(
      req.file.buffer,
      req.file.originalname,
      req.file.mimetype
    );

    // ── Search Qdrant ────────────────────────────────────────
    const searchResults = await searchVoicePoints(
      vector,
      incomingUserId,    // if null → global search
      3                  // top-3 candidates
    );

    // ── Evaluate match ───────────────────────────────────────
    const bestMatch = searchResults.length > 0 ? searchResults[0] : null;
    const bestScore = bestMatch ? bestMatch.score : 0;
    const isMatch = bestScore >= MATCH_THRESHOLD;

    let resolvedUserId = incomingUserId; // may remain null

    if (isMatch && bestMatch) {
      // In Case B (no user_id supplied) we learn the identity from the match
      resolvedUserId = resolvedUserId || bestMatch.payload.user_id;
    }

    // ── Store this voice sample ──────────────────────────────
    let stored = false;
    let newPointId = null;

    if (resolvedUserId) {
      newPointId = uuidv4();
      await upsertVoicePoint(newPointId, vector, {
        user_id: resolvedUserId,
        date: storedDate,
        original_filename: req.file.originalname,
        file_mimetype: req.file.mimetype,
        file_size_bytes: req.file.size,
        created_at: new Date().toISOString(),
      });
      stored = true;
    }

    // ── Count stored samples (informational) ─────────────────
    let totalSamplesForUser = null;
    if (resolvedUserId) {
      totalSamplesForUser = await countVoicePointsForUser(resolvedUserId);
    }

    // ── Build response ───────────────────────────────────────
    const response = {
      success: true,
      match: isMatch,
      user_id: isMatch ? resolvedUserId : null,
      confidence: parseFloat(bestScore.toFixed(4)),
      threshold_used: MATCH_THRESHOLD,
      // Top candidates (sanitised)
      candidates: searchResults.slice(0, 3).map((r) => ({
        user_id: r.payload.user_id,
        score: parseFloat(r.score.toFixed(4)),
        date: r.payload.date,
      })),
      storage: {
        stored,
        point_id: newPointId,
        date_stored: storedDate,
        total_voice_samples_for_user: totalSamplesForUser,
        note: !stored
          ? "Voice not stored — could not resolve a user_id (no match found and no user_id provided)."
          : `Stored under user_id: ${resolvedUserId}`,
      },
    };

    return res.status(200).json(response);
  } catch (err) {
    console.error("[voice-match] Error:", err.message);
    return res.status(500).json({
      success: false,
      error: err.message || "Internal server error.",
    });
  }
});

module.exports = router;
