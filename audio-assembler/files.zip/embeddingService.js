const axios = require("axios");
const FormData = require("form-data");

const BASE_URL = process.env.HF_EMBEDDING_URL;

// ─────────────────────────────────────────
//  Text embedding  →  768-dim vector
// ─────────────────────────────────────────
async function getTextEmbedding(text) {
  try {
    const response = await axios.post(
      `${BASE_URL}/embed`,
      { text },
      {
        headers: { "Content-Type": "application/json" },
        timeout: 30000,
      }
    );

    // Handle both { embedding: [...] } and { embeddings: [...] } shapes
    const data = response.data;
    const vector = data.embedding || data.embeddings || data.vector || data;

    if (!Array.isArray(vector)) {
      throw new Error(
        `Unexpected text embedding response shape: ${JSON.stringify(data)}`
      );
    }
    if (vector.length !== 768) {
      throw new Error(
        `Expected 768-dim text embedding, got ${vector.length}`
      );
    }
    return vector;
  } catch (err) {
    const msg = err.response
      ? `HF API error ${err.response.status}: ${JSON.stringify(err.response.data)}`
      : err.message;
    throw new Error(`Text embedding failed — ${msg}`);
  }
}

// ─────────────────────────────────────────
//  Voice embedding  →  512-dim vector
//    fileBuffer : Buffer
//    filename   : original file name (e.g. "recording.wav")
//    mimetype   : e.g. "audio/wav"
// ─────────────────────────────────────────
async function getVoiceEmbedding(fileBuffer, filename, mimetype) {
  try {
    const form = new FormData();
    form.append("file", fileBuffer, {
      filename: filename || "voice.wav",
      contentType: mimetype || "audio/wav",
    });

    const response = await axios.post(`${BASE_URL}/voice-embed`, form, {
      headers: { ...form.getHeaders() },
      timeout: 60000, // voice processing can be slower
    });

    const data = response.data;
    const vector = data.embedding || data.embeddings || data.vector || data;

    if (!Array.isArray(vector)) {
      throw new Error(
        `Unexpected voice embedding response shape: ${JSON.stringify(data)}`
      );
    }
    if (vector.length !== 512) {
      throw new Error(
        `Expected 512-dim voice embedding, got ${vector.length}`
      );
    }
    return vector;
  } catch (err) {
    const msg = err.response
      ? `HF API error ${err.response.status}: ${JSON.stringify(err.response.data)}`
      : err.message;
    throw new Error(`Voice embedding failed — ${msg}`);
  }
}

module.exports = { getTextEmbedding, getVoiceEmbedding };
