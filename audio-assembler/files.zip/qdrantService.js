const { QdrantClient } = require("@qdrant/js-client-rest");

const client = new QdrantClient({
  url: process.env.QDRANT_URL || "http://localhost:6333",
  ...(process.env.QDRANT_API_KEY && { apiKey: process.env.QDRANT_API_KEY }),
});

const TEXT_COLLECTION = process.env.TEXT_COLLECTION || "text_embeddings";
const VOICE_COLLECTION = process.env.VOICE_COLLECTION || "voice_embeddings";

// ─────────────────────────────────────────
//  Init: create collections if not present
// ─────────────────────────────────────────
async function initCollections() {
  const existing = await client.getCollections();
  const names = existing.collections.map((c) => c.name);

  if (!names.includes(TEXT_COLLECTION)) {
    await client.createCollection(TEXT_COLLECTION, {
      vectors: { size: 768, distance: "Cosine" },
    });
    // Index fields used in filters for fast lookup
    await client.createPayloadIndex(TEXT_COLLECTION, {
      field_name: "user_id",
      field_schema: "keyword",
    });
    await client.createPayloadIndex(TEXT_COLLECTION, {
      field_name: "date",
      field_schema: "keyword",
    });
    console.log(`✅ Created collection: ${TEXT_COLLECTION}`);
  }

  if (!names.includes(VOICE_COLLECTION)) {
    await client.createCollection(VOICE_COLLECTION, {
      vectors: { size: 512, distance: "Cosine" },
    });
    await client.createPayloadIndex(VOICE_COLLECTION, {
      field_name: "user_id",
      field_schema: "keyword",
    });
    await client.createPayloadIndex(VOICE_COLLECTION, {
      field_name: "date",
      field_schema: "keyword",
    });
    console.log(`✅ Created collection: ${VOICE_COLLECTION}`);
  }
}

// ─────────────────────────────────────────
//  TEXT — upsert
// ─────────────────────────────────────────
async function upsertTextPoint(pointId, vector, payload) {
  await client.upsert(TEXT_COLLECTION, {
    wait: true,
    points: [{ id: pointId, vector, payload }],
  });
}

// ─────────────────────────────────────────
//  TEXT — search (filter by user_id + optional date)
// ─────────────────────────────────────────
async function searchTextPoints(vector, userId, date, limit) {
  const mustConditions = [
    { key: "user_id", match: { value: userId } },
  ];

  if (date) {
    mustConditions.push({ key: "date", match: { value: date } });
  }

  const results = await client.search(TEXT_COLLECTION, {
    vector,
    filter: { must: mustConditions },
    limit: limit || parseInt(process.env.QUERY_SEARCH_LIMIT) || 5,
    with_payload: true,
    score_threshold: 0.3,
  });

  return results;
}

// ─────────────────────────────────────────
//  VOICE — upsert
// ─────────────────────────────────────────
async function upsertVoicePoint(pointId, vector, payload) {
  await client.upsert(VOICE_COLLECTION, {
    wait: true,
    points: [{ id: pointId, vector, payload }],
  });
}

// ─────────────────────────────────────────
//  VOICE — search
//    userId provided  → filter to that user only
//    userId absent    → search globally (identity recognition)
// ─────────────────────────────────────────
async function searchVoicePoints(vector, userId, limit = 1) {
  const searchOptions = {
    vector,
    limit,
    with_payload: true,
    score_threshold: 0.5, // broad pre-filter; hard threshold applied in route
  };

  if (userId) {
    searchOptions.filter = {
      must: [{ key: "user_id", match: { value: userId } }],
    };
  }

  const results = await client.search(VOICE_COLLECTION, searchOptions);
  return results;
}

// ─────────────────────────────────────────
//  VOICE — count stored samples for a user
// ─────────────────────────────────────────
async function countVoicePointsForUser(userId) {
  const result = await client.count(VOICE_COLLECTION, {
    filter: {
      must: [{ key: "user_id", match: { value: userId } }],
    },
  });
  return result.count;
}

module.exports = {
  initCollections,
  upsertTextPoint,
  searchTextPoints,
  upsertVoicePoint,
  searchVoicePoints,
  countVoicePointsForUser,
};
