# RAG Application — Node.js

Full Retrieval-Augmented Generation (RAG) API with:
- **Qdrant** — vector database (text: 768-dim, voice: 512-dim)
- **HuggingFace Space** — text & voice embeddings
- **Groq (LLaMA 3.3-70B)** — answer formatting

---

## Setup

### 1. Prerequisites
- Node.js ≥ 18
- Qdrant running locally (`docker run -p 6333:6333 qdrant/qdrant`) OR a cloud Qdrant instance

### 2. Install
```bash
cd rag-app
npm install
```

### 3. Configure `.env`
Edit `.env` — the defaults work if Qdrant runs on localhost:6333.
Set `QDRANT_API_KEY` only if your Qdrant instance requires one.

### 4. Start
```bash
npm start          # production
npm run dev        # development (nodemon)
```

---

## API Reference

---

### POST `/upload-text`
Embed and store a text chunk for a user.

**Content-Type:** `application/json`

**Body:**
```json
{
  "user_id": "alice",
  "content": "The quarterly revenue for Q3 2024 was $4.2M.",
  "date": "2024-10-01"
}
```
- `user_id` — required
- `content` — required
- `date` — optional (defaults to today)

**Response:**
```json
{
  "success": true,
  "message": "Text embedded and stored successfully.",
  "data": {
    "point_id": "uuid-v4",
    "user_id": "alice",
    "content_preview": "The quarterly revenue for Q3 2024 was $4.2M.",
    "date": "2024-10-01",
    "embedding_dimensions": 768
  }
}
```

---

### POST `/voice-match`
Match a voice sample to a stored user (voice biometrics + identity recognition).

**Content-Type:** `multipart/form-data`

**Fields:**
| Field    | Type   | Required | Description                    |
|----------|--------|----------|--------------------------------|
| `voice`  | file   | ✅        | Audio file (wav/mp3/ogg/flac)  |
| `user_id`| string | ❌        | If given, match against this user only |
| `date`   | string | ❌        | Date to tag this sample with   |

**Behaviour:**
- **With `user_id`** → searches only that user's stored voice samples
- **Without `user_id`** → global search across all users (identity recognition)
- Always stores the voice sample if a `user_id` can be resolved

**Response:**
```json
{
  "success": true,
  "match": true,
  "user_id": "alice",
  "confidence": 0.9312,
  "threshold_used": 0.88,
  "candidates": [
    { "user_id": "alice", "score": 0.9312, "date": "2024-10-01" }
  ],
  "storage": {
    "stored": true,
    "point_id": "uuid-v4",
    "date_stored": "2024-10-15",
    "total_voice_samples_for_user": 4,
    "note": "Stored under user_id: alice"
  }
}
```

---

### POST `/query`
Ask a question — retrieved from stored knowledge, answered by Groq LLaMA.

**Content-Type:** `application/json`

**Body:**
```json
{
  "user_id": "alice",
  "query": "What was the revenue in Q3 2024?",
  "date": "2024-10-01"
}
```
- `user_id` — required
- `query` — required
- `date` — optional; if given, only embeddings from that date are searched

**Response:**
```json
{
  "success": true,
  "user_id": "alice",
  "query": "What was the revenue in Q3 2024?",
  "date_filter": "2024-10-01",
  "answer": "According to your stored data from 2024-10-01, the Q3 2024 quarterly revenue was $4.2M.",
  "sources": [
    {
      "point_id": "uuid-v4",
      "score": 0.9421,
      "date": "2024-10-01",
      "content_preview": "The quarterly revenue for Q3 2024 was $4.2M."
    }
  ],
  "sources_count": 1
}
```

---

## Project Structure
```
rag-app/
├── src/
│   ├── app.js                      ← Express entry point
│   ├── routes/
│   │   ├── uploadText.js           ← POST /upload-text
│   │   ├── voiceMatch.js           ← POST /voice-match
│   │   └── query.js                ← POST /query
│   ├── services/
│   │   ├── embeddingService.js     ← HF Space API calls
│   │   ├── qdrantService.js        ← Qdrant CRUD + search
│   │   └── groqService.js          ← Groq LLM answer generation
│   └── middleware/
│       └── upload.js               ← Multer file upload config
├── .env
└── package.json
```

---

## Qdrant Collections

| Collection        | Dimensions | Distance | Payload fields                   |
|-------------------|------------|----------|----------------------------------|
| `text_embeddings` | 768        | Cosine   | user_id, content, date, created_at |
| `voice_embeddings`| 512        | Cosine   | user_id, date, filename, created_at |

Both `user_id` and `date` are indexed for fast filtering.

---

## Voice Match Threshold
Default: **0.88** (cosine similarity).  
Tune via `VOICE_MATCH_THRESHOLD` in `.env`.  
- Higher → fewer false positives, may miss genuine matches  
- Lower → more inclusive, may allow false positives  
