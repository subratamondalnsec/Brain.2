require("dotenv").config();

const express = require("express");
const { initCollections } = require("./services/qdrantService");

const uploadTextRouter = require("./routes/uploadText");
const voiceMatchRouter = require("./routes/voiceMatch");
const queryRouter     = require("./routes/query");

const app  = express();
const PORT = process.env.PORT || 3000;

// ─────────────────────────────────────────
//  Global middleware
// ─────────────────────────────────────────
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// Request logger
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}]  ${req.method}  ${req.originalUrl}`);
  next();
});

// ─────────────────────────────────────────
//  Health / info routes
// ─────────────────────────────────────────
app.get("/", (_req, res) => {
  res.json({
    service: "RAG API",
    version: "1.0.0",
    status: "running",
    endpoints: {
      "POST /upload-text":  "Embed and store text for a user",
      "POST /voice-match":  "Match a voice sample to a stored user",
      "POST /query":        "Ask a question answered from stored knowledge",
    },
  });
});

app.get("/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ─────────────────────────────────────────
//  Feature routes
// ─────────────────────────────────────────
app.use("/upload-text",  uploadTextRouter);
app.use("/voice-match",  voiceMatchRouter);
app.use("/query",        queryRouter);

// ─────────────────────────────────────────
//  404 handler
// ─────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ success: false, error: "Route not found." });
});

// ─────────────────────────────────────────
//  Global error handler
// ─────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error("[Global Error]", err);
  res.status(err.status || 500).json({
    success: false,
    error: err.message || "Unexpected server error.",
  });
});

// ─────────────────────────────────────────
//  Boot
// ─────────────────────────────────────────
(async () => {
  try {
    console.log("🔄 Connecting to Qdrant and initialising collections...");
    await initCollections();
    console.log("✅ Qdrant collections ready.");

    app.listen(PORT, () => {
      console.log(`\n🚀 RAG API running on http://localhost:${PORT}\n`);
      console.log("  POST  /upload-text   — store text embeddings");
      console.log("  POST  /voice-match   — voice identity matching");
      console.log("  POST  /query         — RAG-powered Q&A\n");
    });
  } catch (err) {
    console.error("❌ Failed to start server:", err.message);
    process.exit(1);
  }
})();
