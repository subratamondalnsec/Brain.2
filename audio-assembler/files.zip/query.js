const express = require("express");
const { getTextEmbedding } = require("../services/embeddingService");
const { searchTextPoints } = require("../services/qdrantService");
const { generateAnswer } = require("../services/groqService");

const router = express.Router();

/**
 * POST /query
 *
 * Body (JSON):
 *   user_id  {string}  required
 *   query    {string}  required
 *   date     {string}  optional — if given, search only embeddings from that date
 *
 * Flow:
 *   1. Embed the query (768-dim).
 *   2. Vector search in text_embeddings filtered by user_id (+date if provided).
 *   3. Pass top-K context chunks to Groq for answer generation.
 *   4. Return structured response.
 */
router.post("/", async (req, res) => {
  try {
    const { user_id, query, date } = req.body;

    // ── Validation ──────────────────────────────────────────
    if (!user_id || typeof user_id !== "string" || !user_id.trim()) {
      return res.status(400).json({
        success: false,
        error: "user_id is required.",
      });
    }

    if (!query || typeof query !== "string" || !query.trim()) {
      return res.status(400).json({
        success: false,
        error: "query is required.",
      });
    }

    const cleanUserId = user_id.trim();
    const cleanQuery = query.trim();

    // ── Embed the query ──────────────────────────────────────
    const queryVector = await getTextEmbedding(cleanQuery);

    // ── Retrieve context from Qdrant ─────────────────────────
    //    date is passed as-is (string | undefined) — undefined = no date filter
    const searchResults = await searchTextPoints(
      queryVector,
      cleanUserId,
      date ? date.trim() : undefined
    );

    // ── Build response when no context found ─────────────────
    if (!searchResults || searchResults.length === 0) {
      const scopeDesc = date
        ? `user '${cleanUserId}' on date '${date}'`
        : `user '${cleanUserId}' (all dates)`;

      return res.status(200).json({
        success: true,
        user_id: cleanUserId,
        query: cleanQuery,
        date_filter: date || null,
        answer:
          `No stored data found for ${scopeDesc}. ` +
          `Please upload text first using POST /upload-text.`,
        sources: [],
        sources_count: 0,
      });
    }

    // ── Generate answer via Groq ─────────────────────────────
    const answer = await generateAnswer(cleanQuery, searchResults, cleanUserId);

    // ── Sanitise sources for response ────────────────────────
    const sources = searchResults.map((r) => ({
      point_id: r.id,
      score: parseFloat(r.score.toFixed(4)),
      date: r.payload.date,
      content_preview:
        r.payload.content?.length > 150
          ? r.payload.content.slice(0, 150) + "…"
          : r.payload.content,
    }));

    return res.status(200).json({
      success: true,
      user_id: cleanUserId,
      query: cleanQuery,
      date_filter: date || null,
      answer,
      sources,
      sources_count: sources.length,
    });
  } catch (err) {
    console.error("[query] Error:", err.message);
    return res.status(500).json({
      success: false,
      error: err.message || "Internal server error.",
    });
  }
});

module.exports = router;
