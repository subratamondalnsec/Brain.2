const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { getTextEmbedding } = require("../services/embeddingService");
const { upsertTextPoint } = require("../services/qdrantService");

const router = express.Router();

/**
 * POST /upload-text
 *
 * Body (JSON):
 *   user_id  {string}  required
 *   content  {string}  required
 *   date     {string}  optional — e.g. "2024-06-01"
 */
router.post("/", async (req, res) => {
  try {
    const { user_id, content, date } = req.body;

    // ── Validation ──────────────────────────────────────────
    if (!user_id || typeof user_id !== "string" || !user_id.trim()) {
      return res.status(400).json({
        success: false,
        error: "user_id is required and must be a non-empty string.",
      });
    }

    if (!content || typeof content !== "string" || !content.trim()) {
      return res.status(400).json({
        success: false,
        error: "content is required and must be a non-empty string.",
      });
    }

    // ── Embed ────────────────────────────────────────────────
    const vector = await getTextEmbedding(content.trim());

    // ── Store in Qdrant ──────────────────────────────────────
    const pointId = uuidv4();
    const storedDate = date || new Date().toISOString().split("T")[0]; // default today

    await upsertTextPoint(pointId, vector, {
      user_id: user_id.trim(),
      content: content.trim(),
      date: storedDate,
      created_at: new Date().toISOString(),
    });

    return res.status(201).json({
      success: true,
      message: "Text embedded and stored successfully.",
      data: {
        point_id: pointId,
        user_id: user_id.trim(),
        content_preview:
          content.trim().length > 120
            ? content.trim().slice(0, 120) + "…"
            : content.trim(),
        date: storedDate,
        embedding_dimensions: vector.length,
      },
    });
  } catch (err) {
    console.error("[upload-text] Error:", err.message);
    return res.status(500).json({
      success: false,
      error: err.message || "Internal server error.",
    });
  }
});

module.exports = router;
