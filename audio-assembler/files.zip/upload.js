const multer = require("multer");

// Store in memory so we can pass the buffer directly to the HF API
const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  const allowed = [
    "audio/wav",
    "audio/wave",
    "audio/x-wav",
    "audio/mpeg",
    "audio/mp3",
    "audio/mp4",
    "audio/ogg",
    "audio/webm",
    "audio/flac",
  ];

  if (allowed.includes(file.mimetype) || file.fieldname === "voice") {
    cb(null, true);
  } else {
    cb(
      new Error(
        `Unsupported file type: ${file.mimetype}. Allowed: wav, mp3, ogg, webm, flac`
      ),
      false
    );
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20 MB max
});

module.exports = upload;
