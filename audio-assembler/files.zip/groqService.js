const Groq = require("groq-sdk");

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

// ─────────────────────────────────────────
//  Generate a RAG answer using retrieved context chunks
// ─────────────────────────────────────────
async function generateAnswer(query, contextChunks, userId) {
  // Build the context block
  const contextText = contextChunks
    .map(
      (chunk, i) =>
        `[${i + 1}] (Date: ${chunk.payload.date || "unknown"}) ${chunk.payload.content}`
    )
    .join("\n\n");

  const systemPrompt = `You are a precise and helpful AI assistant.
Your job is to answer the user's question using ONLY the provided context.
Rules:
- If the answer is present in the context, give a clear, well-structured answer.
- If the context is insufficient, say "I don't have enough information in the stored data to answer this."
- Never fabricate facts outside the context.
- Keep your answer concise and relevant.
- Mention the date of the source when it adds useful context.`;

  const userPrompt = `User ID: ${userId}

Relevant stored information:
${contextText}

Question: ${query}

Answer:`;

  const completion = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    temperature: 0.3,
    max_tokens: 1024,
  });

  return completion.choices[0].message.content;
}

module.exports = { generateAnswer };
